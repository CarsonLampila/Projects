﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    // Prefab
    public GameObject misslePrefab;

    // Edit
    private GameObject missleEdit;

    // Lists
    public List<GameObject> shots = new List<GameObject>();
    public List<Vector3> shotDirections = new List<Vector3>();

    // Camera Wrap
    public Camera wrap;
    public float camHeight;
    public float camWidth;

    // Start is called before the first frame update
    void Start()
    {
        // Camera Wrap
        wrap = Camera.main;
        camHeight = wrap.orthographicSize;
        camWidth = camHeight * wrap.aspect;
    }

    // Update is called once per frame
    void Update()
    {
        // Check for space press
        if (Fire())
        {
            // Never more than 3 shots
            if (shots.Count < 3)
            {
                // Create missle
                CreateBullet();
            }
        }

        // Missle Movement
        Movement();
    }

    /// <summary>
    /// Check for space press
    /// </summary>
    /// <returns></returns>
    bool Fire()
    {
        // Return if space is pressed or not
        if (Input.GetKeyDown(KeyCode.Space))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /// <summary>
    /// Instantiate bullet and required movement variables
    /// </summary>
    void CreateBullet()
    {
        // Generate x and y values
        float xCoord = GetComponent<Vehicle>().position.x;
        float yCoord = GetComponent<Vehicle>().position.y;

        // Instantiate
        missleEdit = Instantiate(misslePrefab, new Vector3(xCoord, yCoord, 0f), Quaternion.identity);
        shots.Add(missleEdit);

        // Copy vehicle direction
        Vector3 direction = GetComponent<Vehicle>().direction;
        shotDirections.Add(direction);
        float angle = GetComponent<Vehicle>().angleOfRotation;
        missleEdit.transform.rotation = Quaternion.Euler(0, 0, angle);
    }

    /// <summary>
    /// Missile Movement
    /// </summary>
    void Movement()
    {
        // Loop through all shots
        for (int t = 0; t < shots.Count; t++)
        {
            // Determine position changes
            Vector3 position = new Vector3(shots[t].transform.position.x, shots[t].transform.position.y, 1f);
            Vector3 direction = shotDirections[t];
            Vector3 velocity = .1f * direction;
            position += velocity;

            // Apply Movement
            shots[t].transform.position = position;

            // Wrap screen x direction
            if (position.x > camWidth || position.x < -camWidth)
            {
                Destroy(shots[t]);
                shots.RemoveAt(t);
                shotDirections.RemoveAt(t);
            }

            // Wrap screen y direction
            if (position.y > camHeight || position.y < -camHeight)
            {
                Destroy(shots[t]);
                shots.RemoveAt(t);
                shotDirections.RemoveAt(t);
            }
        }
    }
}
