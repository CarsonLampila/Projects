﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Split : MonoBehaviour
{
    // Prefabs
    public GameObject astroid1;
    public GameObject astroid2;
    public GameObject astroid3;
    public GameObject astroid4;
    public GameObject astroid5;
    public GameObject astroid6;
    public GameObject astroid7;
    public GameObject astroid8;

    // Edit
    private GameObject astroidEdit;

    // Lists
    private List<GameObject> astroids;
    private List<Vector3> astroidDirections;
    private List<int> sizes;

    // Score
    public int score;

    // Start is called before the first frame update
    void Start()
    {
        // Get variables from other scripts
        astroids = GetComponent<AstroidsGenerator>().allAstroids;
        astroidDirections = GetComponent<AstroidsGenerator>().allDirections;
        sizes = GetComponent<AstroidsGenerator>().astroidSize;

        // Default score
        score = 0;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    /// <summary>
    /// Split astroid into smaller itterations based on size
    /// </summary>
    /// <param name="astroid"></param>
    /// <param name="direction"></param>
    /// <param name="size"></param>
    public void AstroidSplit(GameObject astroid, Vector3 direction, int size)
    {
        // Destroy if smallest
        if (size == 1)
        {
            // Add Score
            score += ScoreCalc(size);
        }
        // Even split 2 new astroids
        else if ((size % 2) == 0)
        {
            // Create 2 smaller astroids
            for (int u = 0; u < 2; u++)
            {
                // Half the size
                int halfSize = size / 2;

                // Instantiate
                astroidEdit = Instantiate(DetectSize(halfSize), new Vector3(astroid.transform.position.x, astroid.transform.position.y, 0f), Quaternion.identity);
                astroids.Add(astroidEdit);

                // Split directions
                int angle = 35;
                if (u == 1)
                {
                    angle = angle * -1;
                }
                Vector3 altered = Quaternion.Euler(0, 0, angle) * direction;
                astroidDirections.Add(altered);

                // Set size
                sizes.Add(halfSize);
            }

            // Add Score
            score += ScoreCalc(size);
        }
        // Uneven split 3 new astroids
        else
        {
            // Create 3 smaller astroids
            for (int u = 0; u < 2; u++)
            {
                // Create 2 smaller astroids
                int tempSize = size - 1;

                int halfSize = tempSize / 2;

                // Instantiate
                astroidEdit = Instantiate(DetectSize(halfSize), new Vector3(astroid.transform.position.x, astroid.transform.position.y, 0f), Quaternion.identity);
                astroids.Add(astroidEdit);

                // Split directions
                int angle = 35;
                if (u == 1)
                {
                    angle = angle * -1;
                }
                Vector3 altered = Quaternion.Euler(0, 0, angle) * direction;
                astroidDirections.Add(altered);

                // Set size
                sizes.Add(halfSize);
            }
            // Create 1 smallest astroid same direction
            // Instantiate
            astroidEdit = Instantiate(DetectSize(1), new Vector3(astroid.transform.position.x, astroid.transform.position.y, 0f), Quaternion.identity);
            astroids.Add(astroidEdit);
            astroidDirections.Add(direction);
            sizes.Add(1);

            // Add Score
            score += ScoreCalc(size);
        }
    }

    /// <summary>
    /// Return astroid prefab based on astroid size
    /// </summary>
    /// <param name="astroidNum"></param>
    /// <returns></returns>
    GameObject DetectSize(int astroidNum)
    {
        switch (astroidNum)
        {
            // Largest
            case 8:
                return astroid8;
                break;

            case 7:
                return astroid7;
                break;

            case 6:
                return astroid6;
                break;

            case 5:
                return astroid5;
                break;

            case 4:
                return astroid4;
                break;

            case 3:
                return astroid3;
                break;

            case 2:
                return astroid2;
                break;

            // Smallest
            case 1:
                return astroid1;
                break;

            default:
                return astroid1;
                break;
        }
    }

    /// <summary>
    /// Return score to add based on astroid size
    /// </summary>
    /// <param name="astroidSize"></param>
    /// <returns></returns>
    int ScoreCalc(int astroidSize)
    {
        switch (astroidSize)
        {
            // Largest
            case 8:
                return 10;
                break;

            case 7:
                return 15;
                break;

            case 6:
                return 20;
                break;

            case 5:
                return 25;
                break;

            case 4:
                return 30;
                break;

            case 3:
                return 35;
                break;

            case 2:
                return 40;
                break;

            // Smallest
            case 1:
                return 50;
                break;

            default:
                return 0;
                break;
        }
    }
}
