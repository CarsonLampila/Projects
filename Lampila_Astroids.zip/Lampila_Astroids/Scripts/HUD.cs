﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HUD : MonoBehaviour
{
    // Connections
    private CollisionManager shipCollision;
    private Split scoreCounter;
    private AstroidsGenerator levelNumber;

    // Variables to be displayed
    private int lives;
    private int score;
    private int level;
    private int astroids;

    // Start is called before the first frame update
    void Start()
    {
        // Connect to other scripts
        shipCollision = GetComponent<CollisionManager>();
        scoreCounter = GetComponent<Split>();
        levelNumber = GetComponent<AstroidsGenerator>();
    }

    // Update is called once per frame
    void Update()
    {
        // Update variables
        lives = shipCollision.lives;
        score = scoreCounter.score;
        level = levelNumber.level;
        astroids = levelNumber.allAstroids.Count;
    }

    // Display
    void OnGUI()
    {
        // Text color: White
        GUI.color = Color.white;

        // Font size: 20
        GUI.skin.box.fontSize = 30;

        // Score
        GUI.Box(new Rect(0, 0, 200, 40), "Score: " + score);

        // Level / Winner
        if (level == 4)
        {
            GUI.Box(new Rect(0, 40, 200, 40), "Winner");
        }
        else
        {
            GUI.Box(new Rect(0, 40, 200, 40), "Level: " + level);
        }

        // Lives / Lose
        if (lives != 0)
        {
            GUI.Box(new Rect(0, 80, 200, 40), "Lives: " + lives);
        }
        else
        {
            GUI.Box(new Rect(0, 80, 200, 40), "Lose");
        }

        // Astroids remaining
        GUI.Box(new Rect(0, 120, 200, 40), "Remaining: " + astroids);
    }
}
