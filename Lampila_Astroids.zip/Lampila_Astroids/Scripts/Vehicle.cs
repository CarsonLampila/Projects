﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vehicle : MonoBehaviour
{      
    // Movement
    public Vector3 position;            
    public Vector3 direction;                  
    public Vector3 velocity;                   
    public Vector3 acceleration;  
    public float angleOfRotation;               
    public float maxSpeed;
    public float accelRate;

    // Camera wraps
    public Camera wrap;                         
    private float camHeight;                
    private float camWidth;                      

    // Use this for initialization
    void Start ()
    {
        // Movement
        position = new Vector3(0, 0, 0);    
        direction = new Vector3(1, 0, 0);           
        velocity = new Vector3(0, 0, 0);

        // Camera Wrap
        wrap = Camera.main;
        camHeight = wrap.orthographicSize;      
        camWidth = camHeight * wrap.aspect;       
    }
	
	// Update is called once per frame
	void Update ()
    {
        RotateVehicle();

        Drive();

        SetTransform();

        ScreenWrap();
    }

    /// <summary>
    /// Changes / Sets the transform component
    /// </summary>
    public void SetTransform()
    {
        // Rotate vehicle sprite
        transform.rotation = Quaternion.Euler(0, 0, angleOfRotation);

        // Set the transform position
        transform.position = position;
    }

    /// <summary>
    /// Acceleration and Decceleration
    /// </summary>
    public void Drive()
    {
        // Accerate if key pressed
        if (StartAccel())
        {
            // Acceleration
            acceleration = accelRate * direction;

            // Applying velocity
            velocity += acceleration;

            // Limit velocity so it doesn't become too high
            velocity = Vector3.ClampMagnitude(velocity, maxSpeed);

            // Add velocity to vehicle's position
            position += velocity;
        }

        // Deccelerate dependent on location
        else
        {
            // X, Y
            velocity.x = velocity.x * .95f;
            velocity.y = velocity.y * .95f;

            // Add velocity to vehicle's position
            position += velocity;
        }
    }

    /// <summary>
    /// Player can control direction
    /// </summary>
    public void RotateVehicle()
    {
        // Left arrow key = rotate left by 3 degrees
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            angleOfRotation += 3;
            direction = Quaternion.Euler(0, 0, 3) * direction;
        }
        // Right arrow key = rotate right by 3 degrees
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            angleOfRotation -= 3;
            direction = Quaternion.Euler(0, 0, -3) * direction;
        }
    }

    /// <summary>
    /// Screen Wrap Vehicle
    /// </summary>
    public void ScreenWrap()
    {
        // Wrap screen x direction
        if (position.x > camWidth || position.x < -camWidth)
        {
            position.x = -position.x;
        }

        // Wrap screen y direction
        if (position.y > camHeight || position.y < -camHeight)
        {
            position.y = -position.y;
        }
    }

    /// <summary>
    /// Check if up arrow is being pressd
    /// </summary>
    /// <returns></returns>
    public bool StartAccel()
    {
        // Return if up arrow is pressed or not
        if (Input.GetKey(KeyCode.UpArrow))
        {
            return true;
        }

        else
        {
            return false;
        }
    }
}
