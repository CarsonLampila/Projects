﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionDetection : MonoBehaviour
{
    // Ship Mins and Maxs
    private float object2MinX;
    private float object2MaxX;
    private float object2MinY;
    private float object2MaxY;

    // Astroid Mins and Maxs
    private float astroidMinX;
    private float astroidMaxX;
    private float astroidMinY;
    private float astroidMaxY;

    // Ship x, y
    private float object2X;
    private float object2Y;

    // Astroid x, y
    private float astroidX;
    private float astroidY;

    // Radii
    private float shipRadius;
    private float astroidRadius;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    /// <summary>
    /// Circle Collision
    /// </summary>
    /// <param name="ship"></param>
    /// <param name="astroid"></param>
    /// <returns></returns>
    public bool CircleCollision(GameObject astroid, SpriteRenderer astroidSize, GameObject object2, SpriteRenderer object2Size)
    {
        // Calculate Vairables
        CalculateVariables(astroid, astroidSize, object2, object2Size);

        // Calculate x value
        float xValues = (object2X - astroidX) * (object2X - astroidX);
        // Calculate y value
        float yValues = (object2Y - astroidY) * (object2Y - astroidY);

        // Calculate distance
        float distance = Mathf.Sqrt(xValues + yValues);

        // Check if distance is less than radii
        if (distance < (shipRadius + astroidRadius))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // Calculate variables to save repetition and space
    void CalculateVariables(GameObject astroid, SpriteRenderer astroidSize, GameObject object2, SpriteRenderer object2Size)
    {
        // Object2 Min and Max
        object2MinX = object2Size.bounds.min.x;
        object2MaxX = object2Size.bounds.max.x;
        object2MinY = object2Size.bounds.min.y;
        object2MaxY = object2Size.bounds.max.y;

        // Astroid Min and Max
        astroidMinX = astroidSize.bounds.min.x;
        astroidMaxX = astroidSize.bounds.max.x;
        astroidMinY = astroidSize.bounds.min.y;
        astroidMaxY = astroidSize.bounds.max.y;

        // X, Y
        object2X = object2.transform.position.x;
        object2Y = object2.transform.position.y;
        astroidX = astroid.transform.position.x;
        astroidY = astroid.transform.position.y;

    
        // Radii
        shipRadius = ((object2MaxX - object2MinX) / 2);
        astroidRadius = ((astroidMaxX - astroidMinX) / 2);

    }

}
