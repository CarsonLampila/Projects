﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AstroidsGenerator : MonoBehaviour
{
    // Prefab
    public GameObject astroid4;

    // Edit
    private GameObject astroidEdit;

    // Variable
    public int level;

    // Lists
    public List<GameObject> allAstroids = new List<GameObject>();
    public List<Vector3> allDirections = new List<Vector3>();
    public List<int> astroidSize = new List<int>();

    // Camera Wrap
    public Camera wrap;                           
    private float camHeight;                     
    private float camWidth;

    // Start is called before the first frame update
    void Start()
    {
        // Camera Wrap
        wrap = Camera.main;
        camHeight = wrap.orthographicSize;   
        camWidth = camHeight * wrap.aspect;

        // Define variable
        level = 1;

        // Generate astroids
        Generate(level);
    }

    // Update is called once per frame
    void Update()
    {
        // Astroid movement
        Movement();

        // Check if all astroids are destroyed
        if (allAstroids.Count == 0)
        {
            level++;
            Generate(level);
        }
    }
    
    /// <summary>
    /// Generate astroids
    /// </summary>
    /// <param name="level"></param>
    void Generate(int level)
    {
        // Number of astroids to be created
        int units = 0;

        // Change dependent on level
        switch (level)
        {
            // Level 1: 8 astroids
            case 1:
                units = 8;
                break;

            // Level 2: 12 Astroids
            case 2:
                units = 12;
                break;

            // Level 3: 16 Astroids
            case 3:
                units = 16;
                break;

            // Default: 1 Astroid
            default:
                units = 1;
                break;
        }

        // Generate large astroids
        for (int a = 0; a < units; a++)
        {
            // X, Y
            float xCoord = 0f;
            float yCoord = 0f;

            // Generate Random position
            int border = Random.Range(1, 5);
            switch (border)
            {
                // Right
                case 1:
                    xCoord = 6.65f;
                    yCoord = LocationY();
                    break;

                // Left
                case 2:
                    xCoord = -6.65f;
                    yCoord = LocationY();
                    break;

                // Up
                case 3:
                    xCoord = LocationX();
                    yCoord = 5f;
                    break;

                // Down
                case 4:
                    xCoord = LocationX();
                    yCoord = -5f;
                    break;
                    
            }

            // Instantiate
            astroidEdit = Instantiate(astroid4, new Vector3(xCoord, yCoord, 0f), Quaternion.identity);
            allAstroids.Add(astroidEdit);

            // Set Size
            astroidSize.Add(4);

            // Determine angle
            Angle();
        }
    }

    /// <summary>
    /// Astroid Movement
    /// </summary>
    void Movement()
    {
        // Loop through all astroids
        for (int t = 0; t < allAstroids.Count; t++)
        {
            // Determine position and direction
            Vector3 position = new Vector3(allAstroids[t].transform.position.x, allAstroids[t].transform.position.y, 1f);
            Vector3 direction = allDirections[t];

            // Determine speed based on size
            float speed = 0f;
            switch (astroidSize[t])
            {
                // Largest = Slowest
                case 8:
                    speed = .0025f;
                    break;

                case 7:
                    speed = .005f;
                    break;

                case 6:
                    speed = .0075f;
                    break;

                case 5:
                    speed = .01f;
                    break;

                case 4:
                    speed = .015f;
                    break;

                case 3:
                    speed = .02f;
                    break;

                case 2:
                    speed = .025f;
                    break;

                // Smallest = Fastest
                case 1:
                    speed = .03f;
                    break;

                // Default
                default:
                    speed = 0f;
                    break;
            }

            //Determine position and velocity
            Vector3 velocity = speed * direction;
            position += velocity;

            // Wrap screen x direction
            if (position.x > camWidth || position.x < -camWidth)
            {
                position.x = -position.x;
            }

            // Wrap screen y direction
            if (position.y > camHeight || position.y < -camHeight)
            {
                position.y = -position.y;
            }

            // Apply movement
            allAstroids[t].transform.position = position;

            // Apply rotation
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            allAstroids[t].transform.rotation = Quaternion.Euler(0, 0, angle);
        }
    }

    /// <summary>
    /// Determine random x location
    /// </summary>
    /// <returns></returns>
    float LocationX()
    {
        // Generate number
        float xCoord = Random.Range(0f, 6.65f);

        // 50/50 pos or neg
        int posOrNeg = Random.Range(1, 3);
        if (posOrNeg == 1)
        {
            xCoord = xCoord * -1;
        }
        
        // Return result
        return xCoord;
    }

    /// <summary>
    /// Determine random y location
    /// </summary>
    /// <returns></returns>
    float LocationY()
    {
        // Generate number
        float yCoord = Random.Range(0f, 5f);

        // 50/50 pos or neg
        int posOrNeg = Random.Range(1, 3);
        if (posOrNeg == 1)
        {
            yCoord = yCoord * -1;
        }

        // Return result
        return yCoord;
    }

    /// <summary>
    /// Determine random angle of movement
    /// </summary>
    void Angle()
    {
        // Generate angle
        float angle = Random.Range(0f, 360f);

        // Create direction vector
        Vector3 direction = new Vector3(1f, 0f, 0f);
        direction = Quaternion.Euler(0, 0, angle) * direction;
        allDirections.Add(direction);
    }
}
