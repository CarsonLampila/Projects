﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Combine : MonoBehaviour
{
    // Prefabs
    public GameObject astroid2;
    public GameObject astroid3;
    public GameObject astroid4;
    public GameObject astroid5;
    public GameObject astroid6;
    public GameObject astroid7;
    public GameObject astroid8;

    // Edit
    private GameObject astroidEdit;

    // Lists
    private List<GameObject> astroids;
    private List<Vector3> astroidDirections;
    private List<int> sizes;

    // Connections
    private GameObject generator;

    // Start is called before the first frame update
    void Start()
    {
        // Connect to other scripts
        generator = GameObject.Find("Manager");
        astroids = generator.GetComponent<AstroidsGenerator>().allAstroids;
        astroidDirections = generator.GetComponent<AstroidsGenerator>().allDirections;
        sizes = generator.GetComponent<AstroidsGenerator>().astroidSize;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    /// <summary>
    /// Combine 2 astroids position, size, and choose a direction
    /// </summary>
    /// <param name="astroid1"></param>
    /// <param name="astroid1Size"></param>
    /// <param name="astroid1Direction"></param>
    /// <param name="astroid2"></param>
    /// <param name="astroid2Size"></param>
    /// <param name="astroid2Direction"></param>
    public void AstroidCombine(GameObject astroid1, int astroid1Size, Vector3 astroid1Direction, GameObject astroid2, int astroid2Size, Vector3 astroid2Direction)
    {
        // Find average position
        float xCoord = Average(astroid1.transform.position.x, astroid2.transform.position.x);
        float yCoord = Average(astroid1.transform.position.y, astroid2.transform.position.y);

        // Combine size
        int size = astroid1Size + astroid2Size;
        if (size > 8)
        {
            size = 8;
        }

        // Instantiate
        astroidEdit = Instantiate(DetectSize(size), new Vector3(xCoord, yCoord, 0f), Quaternion.identity);
        astroids.Add(astroidEdit);
        sizes.Add(size);

        // Choose the direction of the larger astroid
        if (astroid1Size > astroid2Size)
        {
            astroidDirections.Add(astroid1Direction);
        }
        else
        {
            astroidDirections.Add(astroid2Direction);
        }
    }

    /// <summary>
    /// Calculate the average of 2 provide numbers
    /// </summary>
    /// <param name="num1"></param>
    /// <param name="num2"></param>
    /// <returns></returns>
    float Average(float num1, float num2)
    {
        float combo = (num1 + num2) / 2;
        return combo;
    }

    /// <summary>
    /// Return prefab based on astroid size
    /// </summary>
    /// <param name="astroidNum"></param>
    /// <returns></returns>
    GameObject DetectSize(int astroidNum)
    {
        switch (astroidNum)
        {
            // Largest
            case 8:
                return astroid8;
                break;

            case 7:
                return astroid7;
                break;

            case 6:
                return astroid6;
                break;

            case 5:
                return astroid5;
                break;

            case 4:
                return astroid4;
                break;

            case 3:
                return astroid3;
                break;

            // Smallest
            case 2:
                return astroid2;
                break;

            default:
                return astroid2;
                break;
        }
    }
}
