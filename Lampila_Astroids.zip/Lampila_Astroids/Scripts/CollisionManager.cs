﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionManager : MonoBehaviour
{
    // Prefabs
    public GameObject shipPrefab;
    public GameObject astroid1;
    public GameObject astroid2;
    public GameObject astroid3;
    public GameObject astroid4;
    public GameObject astroid5;
    public GameObject astroid6;
    public GameObject astroid7;
    public GameObject astroid8;
    public GameObject misslePrefab;

    // Lists
    private List<GameObject> astroids;
    private List<Vector3> astroidDirections;
    private List<GameObject> missles;
    private List<Vector3> missleDirections;
    private List<int> sizes;

    // Connections
    private GameObject generator;
    private Split seperate;
    private Combine grow;
    private CollisionDetection detect;

    // Sprite Renderers
    public SpriteRenderer shipArea;
    public SpriteRenderer astroid1Area;
    public SpriteRenderer astroid2Area;
    public SpriteRenderer astroid3Area;
    public SpriteRenderer astroid4Area;
    public SpriteRenderer astroid5Area;
    public SpriteRenderer astroid6Area;
    public SpriteRenderer astroid7Area;
    public SpriteRenderer astroid8Area;
    public SpriteRenderer missleArea;

    // Variables
    public int lives;

    // Timers
    private int invincabityTime;
    private bool invincable;
    private int collisionWait;
    private bool wait;


    // Start is called before the first frame update
    void Start()
    {
        // Connect to other scripts
        detect = GetComponent<CollisionDetection>();
        seperate = GetComponent<Split>();
        grow = GetComponent<Combine>();

        generator = GameObject.Find("Manager");
        astroids = generator.GetComponent<AstroidsGenerator>().allAstroids;
        astroidDirections = generator.GetComponent<AstroidsGenerator>().allDirections;
        sizes = generator.GetComponent<AstroidsGenerator>().astroidSize;

        GameObject ship = GameObject.Find("Ship");
        missles = ship.GetComponent<Bullet>().shots;
        missleDirections = ship.GetComponent<Bullet>().shotDirections;

        // Default variables
        lives = 5;
        invincabityTime = 0;
        invincable = false;
        collisionWait = 0;
        wait = false;

        // Define Sprite Renderers and add to lists
        shipArea = shipPrefab.GetComponent<SpriteRenderer>();

        astroid1Area = astroid1.GetComponent<SpriteRenderer>();
        astroid2Area = astroid2.GetComponent<SpriteRenderer>();
        astroid3Area = astroid3.GetComponent<SpriteRenderer>();
        astroid4Area = astroid4.GetComponent<SpriteRenderer>();
        astroid5Area = astroid5.GetComponent<SpriteRenderer>();
        astroid6Area = astroid6.GetComponent<SpriteRenderer>();
        astroid7Area = astroid7.GetComponent<SpriteRenderer>();
        astroid8Area = astroid8.GetComponent<SpriteRenderer>();

        missleArea = misslePrefab.GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        // Loop through all astroids
        for (int p = 0; p < astroids.Count; p++)
        {
            // Determine if any lives remain
            if (lives > 0)
            {
                // Default color
                shipArea.color = Color.white;
            }

            // Brief invincability after hit
            if (invincable)
            {
                // Change color
                shipArea.color = Color.red;

                // Timer
                invincabityTime--;
                if (invincabityTime == 0)
                {
                    invincable = false;
                }
            }

            // Detect player astroid collision 
            else
            { 
                // Check for collision
                if (detect.CircleCollision(astroids[p], DetectSize(sizes[p]), shipPrefab, shipArea))
                {
                    // Decrease lives
                    lives--;

                    // Game Over
                    if (lives == 0)
                    {
                        // Change color
                        shipArea.color = Color.red;

                        // Destroy all astroids
                        foreach (GameObject y in astroids)
                        {
                            Destroy(y);
                        }
                    }

                    // Brief invincability
                    invincable = true;
                    invincabityTime = 500;
                }
                
            }

            // Detect missle astroid collision
            for (int m = 0; m < missles.Count; m++)
            {
                // Check for collision
                if (detect.CircleCollision(astroids[p], DetectSize(sizes[p]), missles[m], missleArea))
                {
                    // Destroy missle
                    Destroy(missles[m]);
                    missles.RemoveAt(m);
                    missleDirections.RemoveAt(m);

                    // Save temp astroid to be passed
                    GameObject tempAstroid = astroids[p];
                    Vector3 tempDirection = astroidDirections[p];
                    int tempSize = sizes[p];

                    // Destroy astroid
                    Destroy(astroids[p]);
                    astroids.RemoveAt(p);
                    astroidDirections.RemoveAt(p);
                    sizes.RemoveAt(p);

                    // Split astroid
                    seperate.AstroidSplit(tempAstroid, tempDirection, tempSize);

                    // Wait before combine
                    wait = true;
                    collisionWait = 750;
                }       
            }

            
            // Detect astroid astroid collision
            // Wait after split
            if (wait)
            {
                // Timer
                collisionWait--;
                if (collisionWait == 0)
                {
                    wait = false;
                }
            }
            else
            {
                // Save temp astroid to be checked against
                GameObject checkAstroid = astroids[p];
                Vector3 checkDirection = astroidDirections[p];
                int checkSize = sizes[p];

                // Delete astroid
                astroids.RemoveAt(p);
                astroidDirections.RemoveAt(p);
                sizes.RemoveAt(p);

                bool check = true;

                // Detect astroid astroid collisions
                for (int n = 0; n < astroids.Count; n++)
                {
                    if (detect.CircleCollision(checkAstroid, DetectSize(checkSize), astroids[n], DetectSize(sizes[n])))
                    {
                        // Cannot collide if total would be above largest available astroid 
                        if (checkSize + sizes[n] <= 8)
                        {
                            // Save temp astroid to be passed
                            GameObject tempAstroid = astroids[n];
                            Vector3 tempDirection = astroidDirections[n];
                            int tempSize = sizes[n];

                            // Destroy astroid
                            Destroy(astroids[n]);
                            astroids.RemoveAt(n);
                            astroidDirections.RemoveAt(n);
                            sizes.RemoveAt(n);

                            // Combine astroids
                            grow.AstroidCombine(checkAstroid, checkSize, checkDirection, tempAstroid, tempSize, tempDirection);

                            // Destory check astroid
                            Destroy(checkAstroid);

                            check = false;

                            // wait after collision
                            wait = true;
                            collisionWait = 750;
                        }
                    }
                }
                // If collision didnt occur
                if (check)
                {
                    // Replace check astroid
                    astroids.Add(checkAstroid);
                    astroidDirections.Add(checkDirection);
                    sizes.Add(checkSize);
                }
            }
            
            
        }
    }

    /// <summary>
    /// Returns Spite rendere based on astroid size
    /// </summary>
    /// <param name="astroidNum"></param>
    /// <returns></returns>
    SpriteRenderer DetectSize(int astroidNum)
    {
        switch (astroidNum)
        {
            // Largest
            case 8:
                return astroid8Area;
                break;

            case 7:
                return astroid7Area;
                break;

            case 6:
                return astroid6Area;
                break;

            case 5:
                return astroid5Area;
                break;

            case 4:
                return astroid4Area;
                break;

            case 3:
                return astroid3Area;
                break;

            case 2:
                return astroid2Area;
                break;

            // Smallest
            case 1:
                return astroid1Area;
                break;

            default:
                return astroid1Area;
                break;
        }
    }
}
