﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generate : MonoBehaviour
{
    // Prefabs
    public GameObject rockPrefab;
    public GameObject turtlePrefab;
    public GameObject fishPrefab;
    public GameObject psgPrefab;
    public GameObject averagePrefab;

    // Edits
    private GameObject rockEdit;
    public GameObject turtleEdit;
    private GameObject fishEdit;
    public GameObject psgEdit;
    private GameObject pillarEdit;
    private GameObject waterEdit;
    public GameObject averageEdit;

    // Lists
    public List<GameObject> rocks;
    public List<GameObject> fishs;
    public List<GameObject> arch;
    public List<GameObject> water;
    public List<Vector3> points;

    // Floats
    public float coord;

    // Bool
    private bool drawLines;
    private bool waterToggle;

    // Terrain
    private Terrain terrain;
    private Vector3 terrainPoint;

    // Color
    public Material red;


    // Start is called before the first frame update
    void Start()
    {
        // Conncections
        terrain = Terrain.activeTerrain;

        // Define Lists
        rocks = new List<GameObject>();
        fishs = new List<GameObject>();
        points = new List<Vector3>();

        // Define variable
        drawLines = true;
        waterToggle = true;

        // Instantiates
        turtleEdit = Instantiate(turtlePrefab, new Vector3(71.3f, 10.5f, 73.8f), Quaternion.identity);

        Rocks();

        Fishs();

        Arch();

        Water();

        psgEdit = Instantiate(psgPrefab, new Vector3(150f, 150f, 150f), Quaternion.identity);

        averageEdit = Instantiate(averagePrefab, new Vector3(150f, 150f, 150f), Quaternion.identity);

        // Define terrain points
        Points();
    }


    // Update is called once per frame
    void Update()
    {
        Average();

        PSGMove();

        // Toggle debug lines
        if (Input.GetKeyDown(KeyCode.D))
        {
            drawLines = !drawLines;
        }

        // Toggle water seek
        if (Input.GetKeyDown(KeyCode.W))
        {
            waterToggle = !waterToggle;
        }
    }


    /// <summary>
    /// Determine random location
    /// </summary>
    /// <returns></returns>
    float Location(int loc)
    {
        switch (loc)
        {
            // X
            case 1:
                // Generate number
                coord = Random.Range(20.0f, 280.0f);
                break;

            // Y
            case 2:
                // Generate number
                coord = Random.Range(85.0f, 215.0f);
                break;

            // Z
            case 3:
                // Generate number
                coord = Random.Range(20.0f, 280.0f);
                break;
        }

        // Return result
        return coord;
    }


    /// <summary>
    /// Instantiate Rocks
    /// </summary>
    void Rocks()
    {
        // 1
        rockEdit = Instantiate(rockPrefab, new Vector3 (71.3f, 4.5f, 73.8f), Quaternion.identity);
        rocks.Add(rockEdit);

        // 2
        rockEdit = Instantiate(rockPrefab, new Vector3(81.6f, 3.6f, 47.9f), Quaternion.identity);
        rocks.Add(rockEdit);

        // 3
        rockEdit = Instantiate(rockPrefab, new Vector3(102.9f, 12.6f, 28.6f), Quaternion.identity);
        rocks.Add(rockEdit);

        // 4
        rockEdit = Instantiate(rockPrefab, new Vector3(63.5f, 4.6f, 14f), Quaternion.identity);
        rocks.Add(rockEdit);

        // 5
        rockEdit = Instantiate(rockPrefab, new Vector3(40.2f, 6.2f, 27.1f), Quaternion.identity);
        rocks.Add(rockEdit);

        // 6
        rockEdit = Instantiate(rockPrefab, new Vector3(18.2f, 3f, 17.3f), Quaternion.identity);
        rocks.Add(rockEdit);

        // 7
        rockEdit = Instantiate(rockPrefab, new Vector3(12.4f, 2.3f, 50.8f), Quaternion.identity);
        rocks.Add(rockEdit);

        // 8
        rockEdit = Instantiate(rockPrefab, new Vector3(23f, 3.5f, 78f), Quaternion.identity);
        rocks.Add(rockEdit);

        // 9
        rockEdit = Instantiate(rockPrefab, new Vector3(27.8f, 9.3f, 100.7f), Quaternion.identity);
        rocks.Add(rockEdit);

        // 10
        rockEdit = Instantiate(rockPrefab, new Vector3(54.8f, 5.2f, 99f), Quaternion.identity);
        rocks.Add(rockEdit);
    }


    /// <summary>
    /// Instantiate Fish
    /// </summary>
    void Fishs()
    {
        // Generate 12 fish
        for (int f = 0; f < 12; f++)
        {
            fishEdit = Instantiate(fishPrefab, new Vector3(Location(1), Location(2), Location(3)), Quaternion.identity);
            fishs.Add(fishEdit);
        }
    }


    /// <summary>
    /// Find all columns in arch and make list
    /// </summary>
    void Arch()
    {
        // L1
        pillarEdit = GameObject.Find("PillarL1");
        arch.Add(pillarEdit);

        // L2
        pillarEdit = GameObject.Find("PillarL2");
        arch.Add(pillarEdit);

        // L3
        pillarEdit = GameObject.Find("PillarL3");
        arch.Add(pillarEdit);

        // L4
        pillarEdit = GameObject.Find("PillarL4");
        arch.Add(pillarEdit);

        // L5
        pillarEdit = GameObject.Find("PillarL5");
        arch.Add(pillarEdit);

        // L6
        pillarEdit = GameObject.Find("PillarL6");
        arch.Add(pillarEdit);

        // R1
        pillarEdit = GameObject.Find("PillarR1");
        arch.Add(pillarEdit);

        // R2
        pillarEdit = GameObject.Find("PillarR2");
        arch.Add(pillarEdit);

        // R3
        pillarEdit = GameObject.Find("PillarR3");
        arch.Add(pillarEdit);

        // R4
        pillarEdit = GameObject.Find("PillarR4");
        arch.Add(pillarEdit);

        // R5
        pillarEdit = GameObject.Find("PillarR5");
        arch.Add(pillarEdit);

        // R6
        pillarEdit = GameObject.Find("PillarR6");
        arch.Add(pillarEdit);

    }


    /// <summary>
    /// Find all water barriers and make list
    /// </summary>
    void Water()
    {
        waterEdit = GameObject.Find("Water");
        water.Add(waterEdit);

        waterEdit = GameObject.Find("W1");
        water.Add(waterEdit);

        waterEdit = GameObject.Find("W2");
        water.Add(waterEdit);

        waterEdit = GameObject.Find("W3");
        water.Add(waterEdit);

        waterEdit = GameObject.Find("W4");
        water.Add(waterEdit);

        waterEdit = GameObject.Find("W5");
        water.Add(waterEdit);
    }


    /// <summary>
    /// Create 30 x 30 Vector3 that represents terrain
    /// </summary>
    void Points()
    {
        // Variables
        int x = -10;
        int z = -10;

        // X - axis
        for (int a = 0; a < 31; a++)
        {
            // Increment
            x = x + 10;
            z = -10;

            // Z - axis
            for (int b = 0; b < 31; b++)
            {
                // Increment
                z = z + 10;

                // Find heights and adjust
                float y = (terrain.terrainData.GetHeight(x, z));
                if (y < 5f)
                {
                    y = y * 3f;
                }
                else
                {
                    y = y * 2f;
                }

                // Add Vectors
                terrainPoint = new Vector3(x, y, z);
                points.Add(terrainPoint);
            }
        }
    }


    /// <summary>
    /// Move PSG when fish is nearby
    /// </summary>
    void PSGMove()
    {
        // Loop through all fish
        for(int t = 0; t < fishs.Count; t++)
        {
            // Check for distance between fish and PSG
            if (Vector3.Distance(fishs[t].transform.position, psgEdit.transform.position) < 25f)
            {
                // Generate variables
                float y = Random.Range(15.0f, 215.0f);
                float x;
                float z;

                // Alternate position generations to prevent PSG from being in terrain
                // Top Half
                if (y < 85f)
                {
                    x = Location(1);
                    z = Location(3);
                }
                // Bottom Half
                else
                {
                    do
                    {
                        x = Location(1);
                    } while (x > 75 && x < 225);

                    do
                    {
                        z = Location(1);
                    } while (z > 75 && z < 225);
                }
                // Move PSG to new location
                psgEdit.transform.position = new Vector3(x, y, z);
            }
        }
    }


    /// <summary>
    /// Find average fish location
    /// </summary>
    void Average()
    {
        // Variables
        float avgX = 0f;
        float avgY = 0f;
        float avgZ = 0f;

        // Loop through all positions
        for (int f = 0; f < fishs.Count; f++)
        {
            avgX += fishs[f].transform.position.x;
            avgY += fishs[f].transform.position.y;
            avgZ += fishs[f].transform.position.z;
        }

        // Find averges
        avgX = avgX / fishs.Count;
        avgY = avgY / fishs.Count;
        avgZ = avgZ / fishs.Count;

        // Move
        averageEdit.transform.position = new Vector3(avgX, avgY, avgZ);
    }


    /// <summary>
    /// Debug Lines
    /// </summary>
    void OnRenderObject()
    {
        // Toggle debug
        if (drawLines)
        {
            // Loop through all rocks
            for (int r = 0; r < rocks.Count; r++)
            {
                // Link rocks to rocks with path
                if (r != 9)
                {
                    red.SetPass(0);
                    GL.Begin(GL.LINES);
                    GL.Vertex(new Vector3(rocks[r].transform.position.x, rocks[r].transform.position.y + 5f, rocks[r].transform.position.z));
                    GL.Vertex(new Vector3(rocks[r + 1].transform.position.x, rocks[r + 1].transform.position.y + 5f, rocks[r + 1].transform.position.z));
                    GL.End();
                }
                else
                {
                    red.SetPass(0);
                    GL.Begin(GL.LINES);
                    GL.Vertex(new Vector3(rocks[r].transform.position.x, rocks[r].transform.position.y + 5f, rocks[r].transform.position.z));
                    GL.Vertex(new Vector3(rocks[0].transform.position.x, rocks[0].transform.position.y + 5f, rocks[0].transform.position.z));
                    GL.End();
                }
            }
        }

        // Toggle water
        if (waterToggle)
        {
            // Show water
            for(int w = 0; w < water.Count; w++)
            {
                water[w].GetComponent<Renderer>().enabled = true;
            }
        }
        else
        {
            // Hide water
            for (int w = 0; w < water.Count; w++)
            {
                water[w].GetComponent<Renderer>().enabled = false;
            }
        }
    }
}
