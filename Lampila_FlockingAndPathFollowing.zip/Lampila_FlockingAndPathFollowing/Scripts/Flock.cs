﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flock : Vehicle
{
    // Connections
    private GameObject terrain;
    private GameObject generate;
    private GameObject psg;
    private List<Vector3> futureCam;

    // Debugs
    public GameObject averageEdit;

    // Force
    private Vector3 ultimateForce;
    private Vector3 steeringForce;
    public Vector3 averageDirection;

    // Lists
    private List<GameObject> fishs;
    private List<GameObject> cameras;
    private List<Vector3> terrainPoints;
    private List<GameObject> arch;

    // Float
    public float flockDirection;

    // Bool
    private bool seekToggle;

    // Color
    public Material orange;


    // Start is called before the first frame update
    void Start()
    {
        // Base Start
        base.Start();

        // Conncections
        generate = GameObject.Find("Manager");
        fishs = generate.GetComponent<Generate>().fishs;
        cameras = generate.GetComponent<Camera>().cameras;
        terrainPoints = generate.GetComponent<Generate>().points;
        arch = generate.GetComponent<Generate>().arch;
        psg = generate.GetComponent<Generate>().psgEdit;
        averageEdit = generate.GetComponent<Generate>().averageEdit;
        futureCam = generate.GetComponent<Camera>().averageDirection;

        // Define variable
        seekToggle = true;
    }


    // Update is called once per frame
    void Update()
    {
        // Base Update
        base.Update();

        // Boundaries
        base.Boundaries();

        // Toggle PSG seek
        if (Input.GetKeyDown(KeyCode.S))
        {
            seekToggle = !seekToggle;
        }
    }


    /// <summary>
    /// Flocking
    /// </summary>
    public override void CalcSteeringForces()
    {
        // Alignment
        ultimateForce += Alignment();

        // Cohersion
        ultimateForce += base.Seek(Cohersion());

        // Seperation
        ultimateForce += base.Seperation(fishs);

        // Terrain Avoidance
        Vector3 check = TerrainAvoidance();
        if (check != Vector3.zero)
        {
            ultimateForce += base.Flee(check) * 10f;
        }

        // Obstacle Avoidance
        // Loop through all obstacles
        for (int o = 0; o < arch.Count; o++)
        {
            // Check if within distance
            if (base.ObstacleAvoidance(arch[o]) != Vector3.zero)
            {
                // Avoid
                ultimateForce += (base.ObstacleAvoidance(arch[o]) * 10f);
            }
        }

        // Flock movement paths
        // Seek PSG
        if (seekToggle)
        {
            ultimateForce += base.Seek(psg.transform.position);
        }
        // Wander
        else
        {
            ultimateForce += base.Seek(Wander());
        }

        // Normalize for speed
        ultimateForce.Normalize();
        ultimateForce = ultimateForce * maxSpeed;

        // Apply
        base.ApplyForce(ultimateForce);
    }


    /// <summary>
    /// Pull to center location
    /// </summary>
    /// <returns></returns>
    Vector3 Cohersion()
    {
        Vector3 center = averageEdit.transform.position;
        return center;
    }


    /// <summary>
    /// Align velocities
    /// </summary>
    /// <returns></returns>
    Vector3 Alignment()
    {
        // Add all direction velocities
        averageDirection = Vector3.zero;
        for (int f = 0; f < fishs.Count; f++)
        {
            averageDirection += fishs[f].GetComponent<Vehicle>().direction;
        }

        futureCam[0] = averageDirection;

        // Save for debug
        Vector3 desiredVelocity = averageDirection;

        // Normalize for magnitude
        desiredVelocity.Normalize();
        desiredVelocity = desiredVelocity * base.maxSpeed;

        // Calculate steeringForce
        steeringForce = desiredVelocity - base.velocity;

        return steeringForce;
    }


    /// <summary>
    /// Avoid the terrain
    /// </summary>
    /// <returns></returns>
    Vector3 TerrainAvoidance()
    {
        // Variables
        Vector3 closest = Vector3.zero;
        float closestDistance = 999;

        // Loop through all terrain points
        for (int p = 0; p < terrainPoints.Count; p++)
        {
            // Find shortest distance
            float temp = Vector3.Distance(this.transform.position, terrainPoints[p]);
            if (temp < closestDistance)
            {
                closestDistance = temp;
                closest = terrainPoints[p];
            }
        }

        // Ensure distance is close enough
        if (closestDistance > 15f)
        {
            closest = Vector3.zero;
        }

        return closest;
    }


    /// <summary>
    /// Debug Lines
    /// </summary>
    public void OnRenderObject()
    {
        base.OnRenderObject();

        // Check for toggle
        if (base.drawLines)
        {
            // Average Direction
            orange.SetPass(0);
            GL.Begin(GL.LINES);
            GL.Vertex(averageEdit.transform.position);
            GL.Vertex((averageDirection * 2f) + averageEdit.transform.position);
            GL.End();

            // Show Average Flock
            averageEdit.GetComponent<Renderer>().enabled = true;

            // Show PSG
            psg.GetComponent<Renderer>().enabled = true;
        }
        else
        {
            // Hide Average Flock
            averageEdit.GetComponent<Renderer>().enabled = false;

            // Hide PSG
            psg.GetComponent<Renderer>().enabled = false;
        }
    }
}