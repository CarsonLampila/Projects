﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Follow : Vehicle
{
    // Connections
    private GameObject generate;
    private List<GameObject> rocks;

    // Force
    private Vector3 ultimateForce;

    // Int
    private int seekNum;

    // Color
    public Material black;


    // Start is called before the first frame update
    void Start()
    {
        // Base Start
        base.Start();

        // Conncections
        generate = GameObject.Find("Manager");
        rocks = generate.GetComponent<Generate>().rocks;

        // Define Variables
        seekNum = 1;
    }


    // Update is called once per frame
    void Update()
    {
        // Base Update
        base.Update();
    }


    /// <summary>
    /// Seek rocks in path
    /// </summary>
    public override void CalcSteeringForces()
    {
        // Determine if close to seeked rock
        if (Vector3.Distance(base.vehiclePosition, new Vector3(rocks[seekNum].transform.position.x , rocks[seekNum].transform.position.y + 6f, rocks[seekNum].transform.position.z)) < 5f)
        {
            // Change seek to next rock
            if (seekNum == 9)
            {
                seekNum = 0;
            }
            else
            {
                seekNum++;
            }
        }

        // Seek
        ultimateForce += base.Seek(new Vector3(rocks[seekNum].transform.position.x, rocks[seekNum].transform.position.y + 10f, rocks[seekNum].transform.position.z));

        // Normalize for speed
        ultimateForce.Normalize();
        ultimateForce = ultimateForce * maxSpeed;

        // Apply
        base.ApplyForce(ultimateForce);
    }


    /// <summary>
    /// Debug lines for path
    /// </summary>
    void OnRenderObject()
    {
        // Base Debug Lines
        base.OnRenderObject();

        // Check for toggle
        if (base.drawLines)
        {
            // Target
            black.SetPass(0);
            GL.Begin(GL.LINES);
            GL.Vertex(base.vehiclePosition);
            GL.Vertex(new Vector3(rocks[seekNum].transform.position.x, rocks[seekNum].transform.position.y + 10f, rocks[seekNum].transform.position.z));
            GL.End();
        }
    }
}
