﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Vehicle : MonoBehaviour
{
    // Vectors necessary for force-based movement
    public Vector3 vehiclePosition;
    public Vector3 acceleration;
    public Vector3 direction;
    public Vector3 velocity;

    // Floats
    public float mass;
    public float maxSpeed;
    private float angle;

    // Bool
    public bool drawLines;

    // Colors
    public Material blue;
    public Material green;


    // Use this for initialization
    public void Start()
    {
        // Define variables
        vehiclePosition = transform.position;
        drawLines = true;
        angle = 0f;
    }


    // Update is called once per frame
    public void Update()
    {
        // Calculate childrens movement
        CalcSteeringForces();

        // Toggle debug lines
        if (Input.GetKeyDown(KeyCode.D))
        {
            drawLines = !drawLines;
        }

        // Apply changes
        velocity += acceleration * Time.deltaTime;
        //velocity.y = 0f;
        vehiclePosition += velocity * Time.deltaTime;
        Rotate(direction);
        direction = velocity.normalized;
        acceleration = Vector3.zero;
        transform.position = vehiclePosition;
    }


    /// <summary>
    /// Apply Force
    /// </summary>
    /// <param name="force"></param>
    public void ApplyForce(Vector3 force)
    {
        acceleration += force / mass;
    }


    /// <summary>
    /// Seek
    /// </summary>
    /// <param name="targetPosition">Vector3 position of desired target</param>
    /// <returns>Steering force calculated to seek the desired target</returns>
    public Vector3 Seek(Vector3 targetPosition)
    {
        // Step 1: Find DV
        Vector3 desiredVelocity = targetPosition - vehiclePosition;

        // Step 2: Scale vel to max speed
        // desiredVelocity = Vector3.ClampMagnitude(desiredVelocity, maxSpeed);
        desiredVelocity.Normalize();
        desiredVelocity = desiredVelocity * maxSpeed;

        // Step 3:  Calculate seeking steering force
        Vector3 seekingForce = desiredVelocity - velocity;

        // Step 4: Return force
        return seekingForce;

    }


    /// <summary>
    /// Overloaded seek with target
    /// </summary>
    /// <param name="target">GameObject of the target</param>
    /// <returns>Steering force calculated to seek the desired target</returns>
    public Vector3 Seek(GameObject target)
    {
        return Seek(target.transform.position);
    }


    /// <summary>
    /// Flee
    /// </summary>
    /// <param name="targetPosition"></param>
    public Vector3 Flee(Vector3 targetPosition)
    {
        // Step 1: Find DV
        Vector3 desiredVelocity = vehiclePosition - targetPosition;

        // Step 2: Scale vel to max speed
        // desiredVelocity = Vector3.ClampMagnitude(desiredVelocity, maxSpeed);
        desiredVelocity.Normalize();
        desiredVelocity = desiredVelocity * maxSpeed;

        // Step 3:  Calculate seeking steering force
        Vector3 fleeingForce = desiredVelocity - velocity;

        // Step 4: Return force
        return fleeingForce;
    }


    /// <summary>
    /// Overloaded flee with target
    /// </summary>
    /// <param name="target"></param>
    /// <returns></returns>
    public Vector3 Flee(GameObject target)
    {
        return Flee(target.transform.position);
    }


    /// <summary>
    /// Rotate vehicle
    /// </summary>
    /// <param name="direction"></param>
    void Rotate(Vector3 direction)
    {
        // Apply rotation
        transform.rotation = Quaternion.LookRotation(direction);
    }


    /// <summary>
    /// Child Movement Calc
    /// </summary>
    public abstract void CalcSteeringForces();


    /// <summary>
    /// Obstacle Avoidance
    /// </summary>
    /// <param name="obstacle"></param>
    /// <returns></returns>
    public Vector3 ObstacleAvoidance(GameObject obstacle)
    {
        Vector3 avoid;
        // Front
        if (Vector3.Dot((this.direction + this.vehiclePosition), obstacle.transform.position) > 0)
        {
            // Radius
            if (Vector3.Distance(this.vehiclePosition, obstacle.transform.position) < 15f)
            {
                // Intersection
                MeshRenderer vehicleArea = this.GetComponent<MeshRenderer>();
                float vehicleRadius = (vehicleArea.bounds.max.x - vehicleArea.bounds.min.x) / 2;

                MeshRenderer obstacleArea = obstacle.GetComponent<MeshRenderer>();
                float obstacleRadius = (obstacleArea.bounds.max.x - obstacleArea.bounds.min.x) / 2f;

                if (Vector3.Dot((obstacle.transform.position - this.vehiclePosition), (new Vector3(this.direction.z * 2, 0f, -this.direction.x * 2) + this.vehiclePosition)) < vehicleRadius + obstacleRadius)
                {
                    // Side
                    // Right
                    if (Vector3.Dot((new Vector3(this.direction.z * 2, 0f, -this.direction.x * 2) + this.vehiclePosition), obstacle.transform.position) > 0)
                    {
                        // Apply
                        avoid = new Vector3(this.direction.z * 2, 0f, -this.direction.x * 2) + this.vehiclePosition;

                        avoid.Normalize();
                        avoid = avoid * maxSpeed;
                    }
                    // Left
                    else
                    {
                        // Apply
                        avoid = new Vector3(-this.direction.z * 2, 0f, this.direction.x * 2) + this.vehiclePosition;

                        avoid.Normalize();
                        avoid = avoid * maxSpeed;
                    }
                    return avoid;
                }
            }
        }
        return Vector3.zero;
    }
    

    /// <summary>
    /// Keep within boundaries
    /// </summary>
    public void Boundaries()
    {
        if (vehiclePosition.x > 285f
            || vehiclePosition.x < 15f
            || vehiclePosition.z > 285f
            || vehiclePosition.z < 15f
            || vehiclePosition.y > 225f
            || vehiclePosition.y < 7.5f)
        {
            // Seek the center
            ApplyForce(Seek(new Vector3(150f, 150f, 150f)));
        }
    }


    /// <summary>
    /// Randomly wander when no threat or target
    /// </summary>
    /// <returns></returns>
    public Vector3 Wander()
    {
        // Distance
        Vector3 project = velocity;
        project.Normalize();
        project = project * 2f;

        // Radius
        float radius = 1f;

        // Circle Center
        Vector3 center = vehiclePosition + project;

        // Angle
        angle += Random.Range(-.1f, .1f);

        // Destination
        float circleX = center.x + Mathf.Cos(angle) * radius;
        float circleZ = center.z + Mathf.Sin(angle) * radius;
        float circleY = center.y + Mathf.Tan(angle) * radius;

        Vector3 target = new Vector3(circleX, circleY, circleZ);

        return target;
    }


    /// <summary>
    /// Seperation from similar objects
    /// </summary>
    /// <param name="friends"></param>
    /// <returns></returns>
    public Vector3 Seperation(List<GameObject> friends)
    {
        // Define variables
        List<GameObject> close = new List<GameObject>();
        Vector3 totalForce = Vector3.zero;

        // Loop through all same objects
        for (int f = 0; f < friends.Count; f++)
        {
            // Remove self from list
            if (Vector3.Distance(this.vehiclePosition, friends[f].transform.position) != 0f)
            {
                // Check if within radius
                if (Vector3.Distance(this.vehiclePosition, friends[f].transform.position) < 20f)
                {
                    // Add to new list
                    close.Add(friends[f]);
                    
                    // Change maxSpeed to allow flock to travel faster
                    maxSpeed = 45f;
                }
                else
                {
                    // Change maxSpeed to have individual speed be simillar to flock speed
                    maxSpeed = 20f;
                }
            }
        }

        // Loop through all objects within radius
        for (int c = 0; c < close.Count; c++)
        {
            // Add fleeing force from all
            totalForce += Flee(close[c]);
        }

        // Return total force
        return totalForce;
    }


    /// <summary>
    /// Debug Lines
    /// </summary>
    public void OnRenderObject()
    {
        // Check for toggle
        if (drawLines)
        {
            // Forword
            green.SetPass(0);
            GL.Begin(GL.LINES);
            GL.Vertex(vehiclePosition);
            GL.Vertex(direction * 15f + vehiclePosition);
            GL.End();

            // Right
            blue.SetPass(0);
            GL.Begin(GL.LINES);
            GL.Vertex(vehiclePosition);
            GL.Vertex(new Vector3(direction.z * 15, 0f, -direction.x * 15) + vehiclePosition);
            GL.End();
        }
    }
}

