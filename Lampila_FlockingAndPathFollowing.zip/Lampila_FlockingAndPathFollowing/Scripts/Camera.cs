﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour
{
    // Connections
    private GameObject generate;
    private GameObject turtle;
    private GameObject average;

    // Cameras
    public GameObject topDown;
    public GameObject flockAverage;
    public GameObject flockFront;
    public GameObject side1;
    public GameObject side2;
    public GameObject topFollow;
    public GameObject follower;

    // Lists
    public List<GameObject> cameras;
    private List<string> camName;
    public List<Vector3> averageDirection;

    // Ints
    private int camNum;

    // Smooth camera variables
    public Transform target;
    public float height = 1.50f;
    public float heightDamping = 2.0f;
    public float positionDamping = 2.0f;
    public float rotationDamping = 2.0f;


    // Start is called before the first frame update
    void Start()
    {
        // Default
        camNum = 0;

        // Define Cam Lists
        cameras = new List<GameObject>();
        cameras.Add(topDown);
        cameras.Add(flockAverage);
        cameras.Add(flockFront);
        cameras.Add(side1);
        cameras.Add(side2);
        cameras.Add(follower);
        cameras.Add(topFollow);

        // Define Name Lists
        camName = new List<string>();
        camName.Add("Overhead");
        camName.Add("Average Flock");
        camName.Add("Flock Front");
        camName.Add("Side 1");
        camName.Add("Side 2");
        camName.Add("Path Follower");
        camName.Add("Top Follower");


        // Turn off all cameras
        for (int c = 0; c < cameras.Count; c++)
        {
            cameras[c].SetActive(false);
        }

        // Turn on first camera
        cameras[camNum].SetActive(true);

        // Cam average positions and directions
        averageDirection = new List<Vector3>();
        averageDirection.Add(Vector3.zero);
        average = GameObject.Find("Manager").GetComponent<Generate>().averageEdit;
    }


    // Update is called once per frame
    void Update()
    {
        // Update moving camera positions
        CameraPositions();

        // Change camera on c press
        if (Input.GetKeyDown(KeyCode.C))
        {
            if (camNum == 6)
            {
                cameras[camNum].SetActive(false);
                camNum = 0;
                cameras[camNum].SetActive(true);
            }
            else
            {
                cameras[camNum].SetActive(false);
                camNum++;
                cameras[camNum].SetActive(true);
            }
        }
    }


    // Update is called once per frame
    void LateUpdate()
    {
        target = average.transform;

        // Early exit if there’s no target
        if (!target) return;

        float wantedHeight = target.position.y + height;
        float currentHeight = cameras[1].transform.position.y;
        float currentHeight2 = cameras[2].transform.position.y;


        // Damp the height   
        currentHeight = Mathf.Lerp(currentHeight, wantedHeight,
                                    heightDamping * Time.deltaTime);

        currentHeight2 = Mathf.Lerp(currentHeight2, wantedHeight,
                                    heightDamping * Time.deltaTime);


        // Set the position of the camera   
        Vector3 wantedPosition = target.position + (averageDirection[0] * 10f);
        cameras[1].transform.position = Vector3.Lerp(cameras[1].transform.position, wantedPosition,
                                            Time.deltaTime * positionDamping);

        Vector3 wantedPosition2 = target.position + (averageDirection[0] * 10f);
        cameras[2].transform.position = Vector3.Lerp(cameras[2].transform.position, wantedPosition2,
                                            Time.deltaTime * positionDamping);


        // Adjust the height of the camera
        cameras[1].transform.position = new Vector3(cameras[1].transform.position.x, currentHeight,
                                    cameras[1].transform.position.z);

        cameras[2].transform.position = new Vector3(cameras[2].transform.position.x, currentHeight,
                                            cameras[2].transform.position.z);


        // Set the forward to rotate with time   
        cameras[1].transform.forward = Vector3.Lerp(cameras[1].transform.forward, averageDirection[0],
                                    Time.deltaTime * rotationDamping);

        cameras[2].transform.forward = Vector3.Lerp(cameras[2].transform.forward, -averageDirection[0],
                                            Time.deltaTime * rotationDamping);
    }


    /// <summary>
    /// Update moving camera positions
    /// </summary>
    void CameraPositions()
    {
        // Conncections
        generate = GameObject.Find("Manager");
        turtle = generate.GetComponent<Generate>().turtleEdit;

        // Turtle
        cameras[5].transform.position = new Vector3(turtle.transform.position.x, turtle.transform.position.y + 3f, turtle.transform.position.z);
        cameras[5].transform.rotation = turtle.transform.rotation;
    }


    /// <summary>
    /// Generate text box on screen
    /// </summary>
    void OnGUI()
    {
        // Text color: Blue
        GUI.color = Color.white;
        // Font size: 20
        GUI.skin.box.fontSize = 20;
        // Box size + text
        GUI.Box(new Rect(10, 10, 200, 100), "Press 'c' to change\npoint of view\nCurrent View:\n" + camName[camNum]);

        GUI.Box(new Rect(10, 120, 200, 50), "Press 'd' to toggle\ndebug");

        GUI.Box(new Rect(10, 180, 200, 75), "Press 's' to toggle\nbetween Seeking a\nPSG and Wandering");

        GUI.Box(new Rect(10, 265, 200, 50), "Press 'w' to toggle\nwater");
    }
}
